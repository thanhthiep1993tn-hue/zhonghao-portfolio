# ============================================================
# MPOP7002 Group 8: Italy
# Consolidated R script for report tables and figures
# ============================================================
# This file summarizes the analyses from the group members' separate scripts.
# It does not modify the original R files. Outputs are saved to r_outputs/.


library(readxl)
library(dplyr)
library(tidyr)
library(ggplot2)
library(scales)

options(scipen = 5)

# ------------------------------------------------------------
# 0. File paths
# ------------------------------------------------------------

candidate_data_paths <- c(
  "/Users/zhonghao/Downloads/Group 8 Italy.xlsx",
  "/Users/zhonghao/Downloads/Group 8 Italy (1).xlsx",
  "/Users/zhonghao/Documents/mpop7002/generated_outputs/Group 8 Italy.xlsx",
  "/Users/zhonghao/Documents/mpop7002/generated_outputs/Group 8 Italy (1).xlsx"
)

data_path <- candidate_data_paths[file.exists(candidate_data_paths)][1]
if (is.na(data_path)) {
  stop("Cannot find Group 8 Italy.xlsx. Please update candidate_data_paths at the top of this script.")
}

output_dir <- "/Users/zhonghao/Documents/mpop7002/r_outputs"
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

message("Using data file: ", data_path)
message("Saving outputs to: ", output_dir)

# ------------------------------------------------------------
# 1. Read and clean data
# ------------------------------------------------------------

clean_italy_sheet <- function(sheet_name) {
  read_excel(data_path, sheet = sheet_name) %>%
    rename(
      age = Age,
      male_pop = `Male population by age (in thousands)`,
      female_pop = `Female population by age (in thousands)`,
      births = `Births by age of mother (in thousands)`,
      male_deaths = `Male deaths by age (in thousands)`,
      female_deaths = `Female deaths by age (in thousands)`,
      nax_male = `nax male`,
      nax_female = `nax female`
    ) %>%
    mutate(
      year = as.integer(sheet_name),
      age = trimws(as.character(age)),
      age_num = ifelse(age == "100+", 100, suppressWarnings(as.numeric(age))),
      total_pop = male_pop + female_pop,
      total_deaths = male_deaths + female_deaths,
      asfr = births / female_pop,
      mx_male = male_deaths / male_pop,
      mx_female = female_deaths / female_pop,
      mx_total = total_deaths / total_pop
    )
}

df_1975 <- clean_italy_sheet("1975")
df_2025 <- clean_italy_sheet("2025")

# ------------------------------------------------------------
# 2. Population age-sex composition: 2025 population pyramid
# ------------------------------------------------------------

make_age_group <- function(age_num) {
  cut(
    age_num,
    breaks = c(seq(0, 100, by = 5), Inf),
    right = FALSE,
    labels = c(
      "0-4", "5-9", "10-14", "15-19", "20-24",
      "25-29", "30-34", "35-39", "40-44", "45-49",
      "50-54", "55-59", "60-64", "65-69", "70-74",
      "75-79", "80-84", "85-89", "90-94", "95-99", "100+"
    )
  )
}

age_group_levels <- c(
  "0-4", "5-9", "10-14", "15-19", "20-24",
  "25-29", "30-34", "35-39", "40-44", "45-49",
  "50-54", "55-59", "60-64", "65-69", "70-74",
  "75-79", "80-84", "85-89", "90-94", "95-99", "100+"
)

pyramid_2025 <- df_2025 %>%
  mutate(age_group = factor(make_age_group(age_num), levels = age_group_levels)) %>%
  group_by(age_group) %>%
  summarise(
    Male = sum(male_pop, na.rm = TRUE),
    Female = sum(female_pop, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_longer(cols = c(Male, Female), names_to = "sex", values_to = "population") %>%
  mutate(plot_population = ifelse(sex == "Male", -population, population))

p_pyramid_2025 <- ggplot(pyramid_2025, aes(x = age_group, y = plot_population, fill = sex)) +
  geom_col(width = 0.85) +
  coord_flip() +
  scale_y_continuous(labels = function(x) abs(x)) +
  scale_fill_manual(values = c("Male" = "steelblue", "Female" = "pink")) +
  labs(
    title = "Italy Population Pyramid (2025)",
    x = "Age Group",
    y = "Population (thousands)",
    fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_2_1_Population_Pyramid_Italy_2025.png"),
  p_pyramid_2025,
  width = 8,
  height = 6,
  dpi = 300
)

# ------------------------------------------------------------
# 3. Age-dependency measures
# ------------------------------------------------------------

dependency_summary <- function(data) {
  pop_0_14 <- sum(data$total_pop[data$age_num >= 0 & data$age_num <= 14], na.rm = TRUE)
  pop_15_64 <- sum(data$total_pop[data$age_num >= 15 & data$age_num <= 64], na.rm = TRUE)
  pop_65plus <- sum(data$total_pop[data$age_num >= 65], na.rm = TRUE)

  tibble(
    Year = unique(data$year),
    Child_Dependency_Ratio = pop_0_14 / pop_15_64 * 100,
    Old_Age_Dependency_Ratio = pop_65plus / pop_15_64 * 100,
    Total_Dependency_Ratio = (pop_0_14 + pop_65plus) / pop_15_64 * 100
  )
}

dependency_table <- bind_rows(
  dependency_summary(df_1975),
  dependency_summary(df_2025)
) %>%
  mutate(across(-Year, ~ round(.x, 2)))

dependency_change <- dependency_table %>%
  pivot_longer(-Year, names_to = "Indicator", values_to = "Value") %>%
  pivot_wider(names_from = Year, values_from = Value, names_prefix = "Year_") %>%
  mutate(Change = Year_2025 - Year_1975)

write.csv(dependency_table, file.path(output_dir, "age_dependency_ratios_italy_1975_2025.csv"), row.names = FALSE)
write.csv(dependency_change, file.path(output_dir, "age_dependency_change_italy_1975_2025.csv"), row.names = FALSE)

dependency_plot_data <- dependency_table %>%
  pivot_longer(-Year, names_to = "Indicator", values_to = "Ratio") %>%
  mutate(
    Indicator = recode(
      Indicator,
      Child_Dependency_Ratio = "Child dependency",
      Old_Age_Dependency_Ratio = "Old-age dependency",
      Total_Dependency_Ratio = "Total dependency"
    )
  )

p_dependency <- ggplot(dependency_plot_data, aes(x = factor(Year), y = Ratio, fill = Indicator)) +
  geom_col(position = position_dodge(width = 0.75), width = 0.65) +
  labs(
    title = "Age-dependency ratios in Italy, 1975 and 2025",
    x = "Year",
    y = "Ratio per 100 people aged 15-64",
    fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_3_1_Age_Dependency_Ratios_Italy_1975_2025.png"),
  p_dependency,
  width = 8,
  height = 5.5,
  dpi = 300
)

# ------------------------------------------------------------
# 4. Fertility measures
# ------------------------------------------------------------

rep_1975 <- df_1975 %>% filter(age_num >= 15, age_num <= 49)
rep_2025 <- df_2025 %>% filter(age_num >= 15, age_num <= 49)

asfr_single_age <- bind_rows(
  rep_1975 %>% transmute(Year = 1975, Age = age_num, ASFR = asfr),
  rep_2025 %>% transmute(Year = 2025, Age = age_num, ASFR = asfr)
)

p_asfr <- ggplot(asfr_single_age, aes(x = Age, y = ASFR, color = factor(Year))) +
  geom_line(linewidth = 1.1) +
  scale_color_manual(values = c("1975" = "blue", "2025" = "red")) +
  labs(
    title = "Age-Specific Fertility Rates, Italy 1975 and 2025",
    x = "Age of Mother",
    y = "Age-Specific Fertility Rate",
    color = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_4_1_ASFR_Italy_1975_2025.png"),
  p_asfr,
  width = 8,
  height = 5.5,
  dpi = 300
)

asfr_by_age_group <- bind_rows(rep_1975, rep_2025) %>%
  mutate(
    age_group = cut(
      age_num,
      breaks = c(15, 20, 25, 30, 35, 40, 45, 50),
      labels = c("15-19", "20-24", "25-29", "30-34", "35-39", "40-44", "45-49"),
      right = FALSE
    )
  ) %>%
  group_by(year, age_group) %>%
  summarise(
    births = sum(births, na.rm = TRUE),
    female_pop = sum(female_pop, na.rm = TRUE),
    asfr_group = births / female_pop,
    .groups = "drop"
  ) %>%
  mutate(asfr_group = round(asfr_group, 4))

write.csv(asfr_single_age, file.path(output_dir, "asfr_single_age_italy_1975_2025.csv"), row.names = FALSE)
write.csv(asfr_by_age_group, file.path(output_dir, "asfr_by_age_group_italy_1975_2025.csv"), row.names = FALSE)

fertility_summary <- function(data) {
  reproductive <- data %>% filter(age_num >= 15, age_num <= 49)
  total_births <- sum(data$births, na.rm = TRUE)
  total_population <- sum(data$total_pop, na.rm = TRUE)
  female_15_49 <- sum(reproductive$female_pop, na.rm = TRUE)
  tfr <- sum(reproductive$asfr, na.rm = TRUE)
  prop_female_births <- 100 / 205

  tibble(
    Year = unique(data$year),
    TFR = tfr,
    CBR_per_1000 = total_births / total_population * 1000,
    GFR_per_1000 = total_births / female_15_49 * 1000,
    GRR = tfr * prop_female_births,
    Total_Births_Thousands = total_births,
    Total_Population_Thousands = total_population,
    Female_15_49_Thousands = female_15_49
  )
}

fertility_table <- bind_rows(
  fertility_summary(df_1975),
  fertility_summary(df_2025)
) %>%
  mutate(across(-Year, ~ round(.x, 4)))

write.csv(fertility_table, file.path(output_dir, "fertility_summary_italy_1975_2025.csv"), row.names = FALSE)

# ------------------------------------------------------------
# 5. Mortality: life tables and standardization
# ------------------------------------------------------------

create_life_table <- function(data, sex = "male") {
  if (sex == "male") {
    lt_data <- data %>%
      transmute(age = age_num, nNx = male_pop, nDx = male_deaths, nax = nax_male)
  } else {
    lt_data <- data %>%
      transmute(age = age_num, nNx = female_pop, nDx = female_deaths, nax = nax_female)
  }

  lt_data <- lt_data %>%
    mutate(
      n = c(diff(age), 0),
      nmx = nDx / nNx,
      nqx = n * nmx / (1 + (n - nax) * nmx),
      npx = 1 - nqx
    )

  lt_data$nqx[nrow(lt_data)] <- 1
  lt_data$npx[nrow(lt_data)] <- 0

  lt_data <- lt_data %>%
    mutate(
      lx = 100000 * cumprod(c(1, npx[-nrow(lt_data)])),
      ndx = c(-diff(lx), lx[nrow(lt_data)]),
      nLx = (lx - ndx) * n + ndx * nax,
      Tx = sum(nLx) - cumsum(nLx) + nLx,
      ex = Tx / lx
    )

  lt_data
}

lt_1975_male <- create_life_table(df_1975, "male")
lt_1975_female <- create_life_table(df_1975, "female")
lt_2025_male <- create_life_table(df_2025, "male")
lt_2025_female <- create_life_table(df_2025, "female")

life_expectancy_table <- tibble(
  Year = c(1975, 1975, 2025, 2025),
  Sex = c("Male", "Female", "Male", "Female"),
  Life_Expectancy_at_Birth = c(
    lt_1975_male$ex[1],
    lt_1975_female$ex[1],
    lt_2025_male$ex[1],
    lt_2025_female$ex[1]
  )
) %>%
  mutate(Life_Expectancy_at_Birth = round(Life_Expectancy_at_Birth, 2))

write.csv(life_expectancy_table, file.path(output_dir, "life_expectancy_italy_1975_2025.csv"), row.names = FALSE)

cdr_1975 <- sum(df_1975$total_deaths, na.rm = TRUE) / sum(df_1975$total_pop, na.rm = TRUE)
cdr_2025 <- sum(df_2025$total_deaths, na.rm = TRUE) / sum(df_2025$total_pop, na.rm = TRUE)

standard_population <- df_1975 %>%
  select(age = age_num, pop_1975 = total_pop) %>%
  left_join(df_2025 %>% select(age = age_num, pop_2025 = total_pop), by = "age") %>%
  mutate(standard_weight = (pop_1975 + pop_2025) / sum(pop_1975 + pop_2025))

ascdr_1975 <- df_1975 %>%
  select(age = age_num, mx_total) %>%
  left_join(standard_population, by = "age") %>%
  summarise(rate = sum(mx_total * standard_weight, na.rm = TRUE)) %>%
  pull(rate)

ascdr_2025 <- df_2025 %>%
  select(age = age_num, mx_total) %>%
  left_join(standard_population, by = "age") %>%
  summarise(rate = sum(mx_total * standard_weight, na.rm = TRUE)) %>%
  pull(rate)

mortality_standardization_table <- tibble(
  Year = rep(c(1975, 2025), each = 2),
  Metric = rep(c("Crude Death Rate (CDR)", "Age-Standardized CDR (ASCDR)"), times = 2),
  Value_per_1000 = round(c(cdr_1975, ascdr_1975, cdr_2025, ascdr_2025) * 1000, 2)
)

write.csv(mortality_standardization_table, file.path(output_dir, "mortality_cdr_ascdr_italy_1975_2025.csv"), row.names = FALSE)

p_mortality_standardization <- ggplot(
  mortality_standardization_table,
  aes(x = factor(Year), y = Value_per_1000, fill = Metric)
) +
  geom_col(position = position_dodge(width = 0.7), width = 0.6) +
  geom_text(
    aes(label = sprintf("%.2f", Value_per_1000)),
    position = position_dodge(width = 0.7),
    vjust = -0.45,
    size = 4
  ) +
  scale_fill_manual(values = c("Crude Death Rate (CDR)" = "#4A6572", "Age-Standardized CDR (ASCDR)" = "#D32F2F")) +
  labs(
    title = "Figure 5.1: Comparison of CDR and Age-Standardized CDR for Italy (1975 vs 2025)",
    x = "Year",
    y = "Mortality Rate per 1,000 population",
    fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_5_1_Mortality_Paradox.png"),
  p_mortality_standardization,
  width = 8.5,
  height = 6,
  dpi = 300
)

mortality_curve_data <- bind_rows(
  lt_1975_male %>% mutate(Year = "1975", Sex = "Male"),
  lt_1975_female %>% mutate(Year = "1975", Sex = "Female"),
  lt_2025_male %>% mutate(Year = "2025", Sex = "Male"),
  lt_2025_female %>% mutate(Year = "2025", Sex = "Female")
) %>%
  mutate(Group = factor(paste(Year, Sex), levels = c("1975 Male", "1975 Female", "2025 Male", "2025 Female")))

academic_colors <- c("1975 Male" = "#4A6572", "1975 Female" = "#94A4AC", "2025 Male" = "#D32F2F", "2025 Female" = "#FF8A80")
academic_linetypes <- c("1975 Male" = "dashed", "1975 Female" = "dashed", "2025 Male" = "solid", "2025 Female" = "solid")

p_asmr <- ggplot(mortality_curve_data, aes(x = age, y = nmx, color = Group, linetype = Group)) +
  geom_line(linewidth = 1.1) +
  scale_y_log10(labels = label_scientific(digits = 2)) +
  scale_color_manual(values = academic_colors) +
  scale_linetype_manual(values = academic_linetypes) +
  labs(
    title = "Figure 5.2: Age-Specific Mortality Rates (nmx) for Italy (1975 vs 2025)",
    x = "Exact Age (x)",
    y = "Mortality Rate (nmx, log-10 scale)",
    color = NULL,
    linetype = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_5_2_ASMR_J_Curve.png"),
  p_asmr,
  width = 8.5,
  height = 6,
  dpi = 300
)

p_survival <- ggplot(mortality_curve_data, aes(x = age, y = lx, color = Group, linetype = Group)) +
  geom_line(linewidth = 1.1) +
  scale_y_continuous(labels = comma, limits = c(0, 105000), expand = c(0, 0)) +
  scale_x_continuous(breaks = seq(0, 100, by = 10)) +
  scale_color_manual(values = academic_colors) +
  scale_linetype_manual(values = academic_linetypes) +
  labs(
    title = "Figure 5.3: Trends in Survival Functions (lx) for Italy (1975 vs 2025)",
    x = "Exact Age (x)",
    y = "Number of Survivors (lx, radix = 100,000)",
    color = NULL,
    linetype = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_5_3_Survival_Rectangularization.png"),
  p_survival,
  width = 8.5,
  height = 6,
  dpi = 300
)

# ------------------------------------------------------------
# 6. Population projection, 2025-2075
# ------------------------------------------------------------

make_qx_from_mx <- function(mx, ax) {
  qx <- mx / (1 + (1 - ax) * mx)
  pmin(pmax(qx, 0), 1)
}

project_one_year <- function(pop_male, pop_female, asfr, px_male, px_female) {
  total_births <- sum(pop_female * asfr, na.rm = TRUE)
  male_births <- total_births * 105 / 205
  female_births <- total_births * 100 / 205

  next_male <- numeric(length(pop_male))
  next_female <- numeric(length(pop_female))

  next_male[1] <- male_births * px_male[1]
  next_female[1] <- female_births * px_female[1]

  next_male[2:100] <- pop_male[1:99] * px_male[1:99]
  next_female[2:100] <- pop_female[1:99] * px_female[1:99]

  # Open age group: 100+ includes survivors from age 99 and existing 100+.
  next_male[101] <- pop_male[100] * px_male[100] + pop_male[101] * px_male[101]
  next_female[101] <- pop_female[100] * px_female[100] + pop_female[101] * px_female[101]

  list(male = next_male, female = next_female, births = total_births)
}

projection_base <- df_2025 %>% arrange(age_num)
ages <- projection_base$age_num

asfr_2025 <- ifelse(ages >= 15 & ages <= 49, projection_base$asfr, 0)
asfr_2025[is.na(asfr_2025)] <- 0

qx_male_2025 <- make_qx_from_mx(projection_base$mx_male, projection_base$nax_male)
qx_female_2025 <- make_qx_from_mx(projection_base$mx_female, projection_base$nax_female)
px_male_2025 <- 1 - qx_male_2025
px_female_2025 <- 1 - qx_female_2025

projection_pop <- list()
projection_pop[["2025"]] <- projection_base %>%
  transmute(year = 2025, age = age_num, male = male_pop, female = female_pop)

current_male <- projection_base$male_pop
current_female <- projection_base$female_pop

for (year in 2026:2075) {
  projected <- project_one_year(current_male, current_female, asfr_2025, px_male_2025, px_female_2025)
  current_male <- projected$male
  current_female <- projected$female
  projection_pop[[as.character(year)]] <- tibble(
    year = year,
    age = ages,
    male = current_male,
    female = current_female
  )
}

projection_by_age <- bind_rows(projection_pop) %>%
  mutate(total = male + female)

projection_summary <- projection_by_age %>%
  group_by(year) %>%
  summarise(
    TotalPopulation = sum(total, na.rm = TRUE) / 1000,
    OldAgeDependency = sum(total[age >= 65], na.rm = TRUE) / sum(total[age >= 15 & age <= 64], na.rm = TRUE) * 100,
    ChildDependency = sum(total[age >= 0 & age <= 14], na.rm = TRUE) / sum(total[age >= 15 & age <= 64], na.rm = TRUE) * 100,
    TotalDependency = (sum(total[age >= 0 & age <= 14], na.rm = TRUE) + sum(total[age >= 65], na.rm = TRUE)) /
      sum(total[age >= 15 & age <= 64], na.rm = TRUE) * 100,
    .groups = "drop"
  )

table_6_1 <- projection_summary %>%
  filter(year %in% c(2025, 2030, 2040, 2050, 2060, 2075)) %>%
  mutate(across(-year, ~ round(.x, 5)))

write.csv(projection_summary, file.path(output_dir, "population_projection_annual_italy_2025_2075.csv"), row.names = FALSE)
write.csv(table_6_1, file.path(output_dir, "table_6_1_population_projection_italy_2025_2075.csv"), row.names = FALSE)
write.csv(projection_by_age, file.path(output_dir, "population_projection_by_age_sex_italy_2025_2075.csv"), row.names = FALSE)

p_projection_total <- ggplot(projection_summary, aes(x = year, y = TotalPopulation)) +
  geom_line(color = "#4A6572", linewidth = 1.1) +
  geom_point(data = table_6_1, color = "#D32F2F", size = 2) +
  labs(
    title = "Italy population projection, 2025-2075",
    x = "Year",
    y = "Total population (millions)"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  file.path(output_dir, "Figure_6_2_Italy_Population_Projection_2025_2075.png"),
  p_projection_total,
  width = 8,
  height = 5.5,
  dpi = 300
)

projection_dependency_long <- projection_summary %>%
  select(year, OldAgeDependency, ChildDependency, TotalDependency) %>%
  pivot_longer(-year, names_to = "Indicator", values_to = "Ratio") %>%
  mutate(
    Indicator = recode(
      Indicator,
      OldAgeDependency = "Old-age dependency",
      ChildDependency = "Child dependency",
      TotalDependency = "Total dependency"
    )
  )

p_projection_dependency <- ggplot(projection_dependency_long, aes(x = year, y = Ratio, color = Indicator)) +
  geom_line(linewidth = 1.1) +
  labs(
    title = "Projected population dependency ratios, 2025-2075",
    x = "Year",
    y = "Ratio per 100 people aged 15-64",
    color = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_6_3_Projected_Dependency_Ratios_2025_2075.png"),
  p_projection_dependency,
  width = 8,
  height = 5.5,
  dpi = 300
)

pyramid_2075 <- projection_by_age %>%
  filter(year == 2075) %>%
  mutate(age_group = factor(make_age_group(age), levels = age_group_levels)) %>%
  group_by(age_group) %>%
  summarise(Male = sum(male), Female = sum(female), .groups = "drop") %>%
  pivot_longer(cols = c(Male, Female), names_to = "sex", values_to = "population") %>%
  mutate(plot_population = ifelse(sex == "Male", -population, population))

p_pyramid_2075 <- ggplot(pyramid_2075, aes(x = age_group, y = plot_population, fill = sex)) +
  geom_col(width = 0.85) +
  coord_flip() +
  scale_y_continuous(labels = function(x) abs(round(x, 0))) +
  scale_fill_manual(values = c("Male" = "steelblue", "Female" = "pink")) +
  labs(
    title = "Italy Projected Population Pyramid (2075)",
    x = "Age Group",
    y = "Population (thousands)",
    fill = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

ggsave(
  file.path(output_dir, "Figure_6_1_Projected_Population_Pyramid_Italy_2075.png"),
  p_pyramid_2075,
  width = 8,
  height = 6,
  dpi = 300
)

# ------------------------------------------------------------
# 7. Console summary
# ------------------------------------------------------------

cat("\n==================== Main output tables ====================\n")
cat("\nAge-dependency table:\n")
print(dependency_table)

cat("\nFertility summary:\n")
print(fertility_table)

cat("\nLife expectancy at birth:\n")
print(life_expectancy_table)

cat("\nMortality CDR/ASCDR:\n")
print(mortality_standardization_table)

cat("\nTable 6.1 projection summary:\n")
print(table_6_1)

cat("\nDone. All outputs saved in:\n", output_dir, "\n")
