
# Set the full file path so the script works even if the working directory changes.
data_path <- "/Users/zhonghao/Downloads/elsa12wide (1).csv"

elsa <- read.csv(data_path)

cat("\n--- PART 0: DATA CHECK ---\n")
cat("Sample size:", nrow(elsa), "\n")
cat("Number of variables:", ncol(elsa), "\n\n")

cat("Variable names:\n")
print(names(elsa))

cat("\nMissing values by variable:\n")
print(colSums(is.na(elsa)))

cat("\nDescriptive statistics:\n")
print(summary(elsa))

# Quick proportions for the two binary physical inactivity variables.
cat("\nProportion with no moderate weekly physical activity:\n")
cat("Wave 1 notact1:", round(mean(elsa$notact1), 3), "\n")
cat("Wave 2 notact2:", round(mean(elsa$notact2), 3), "\n")


# ------------------------------------------------------------------------------
# PART 1: HELPER FUNCTIONS
# ------------------------------------------------------------------------------

# Teacher-style note:
# We keep the models in a list so that the objects are easy to compare later.
mod <- list()

# Function to extract the key row for a linear model.
lm_row <- function(model, term) {
  out <- summary(model)$coefficients
  c(
    b  = out[term, "Estimate"],
    SE = out[term, "Std. Error"],
    t  = out[term, "t value"],
    p  = out[term, "Pr(>|t|)"]
  )
}

# Function to extract the key row for a logistic model and add odds ratios.
logit_row <- function(model, term) {
  out <- summary(model)$coefficients
  b <- out[term, "Estimate"]
  c(
    b  = b,
    SE = out[term, "Std. Error"],
    z  = out[term, "z value"],
    p  = out[term, "Pr(>|z|)"],
    OR = exp(b)
  )
}

# McFadden pseudo-R2 for logistic regression.
mcfadden_r2 <- function(model) {
  null_model <- update(model, . ~ 1)
  1 - as.numeric(logLik(model) / logLik(null_model))
}

# Tjur R2: difference in mean predicted probability between observed 1s and 0s.
tjur_r2 <- function(model) {
  y <- model$y
  p_hat <- fitted(model)
  mean(p_hat[y == 1]) - mean(p_hat[y == 0])
}


# ==============================================================================
# PART 2: Q1 - UNCONDITIONAL EFFECT OF notact1 ON cesd2
# ==============================================================================

# SCENARIO:
# Does lack of physical activity in wave 1 predict depression in wave 2?
#
# Outcome:   cesd2   (CES-D depression score in wave 2, 0-8)
# Predictor: notact1 (1 = no moderate weekly physical activity in wave 1)
#
# Because cesd2 is a score, we use the linear model discussed in class.

mod[["Q1_unconditional_notact1_to_cesd2"]] <- lm(cesd2 ~ notact1, data = elsa)

cat("\n\n--- Q1: UNCONDITIONAL LINEAR MODEL ---\n")
summary(mod[["Q1_unconditional_notact1_to_cesd2"]])

cat("\nKey coefficient for notact1:\n")
print(lm_row(mod[["Q1_unconditional_notact1_to_cesd2"]], "notact1"))

cat("\nR-squared:\n")
print(summary(mod[["Q1_unconditional_notact1_to_cesd2"]])$r.squared)

# Predicted values are useful for substantive interpretation.
q1_pred <- data.frame(notact1 = c(0, 1))
q1_pred$predicted_cesd2 <- predict(mod[["Q1_unconditional_notact1_to_cesd2"]],
                                   newdata = q1_pred)

cat("\nPredicted wave-2 CES-D by wave-1 inactivity:\n")
print(q1_pred)


# ==============================================================================
# PART 3: Q2 - DAG-ADJUSTED TOTAL EFFECT OF notact1 ON cesd2
# ==============================================================================

# DAG / BACK-DOOR LOGIC:
# For the total effect of notact1 -> cesd2, we adjust for pre-treatment common
# causes of activity and later depression.
#
# Controls:
#   cesd1    = baseline depression. It predicts later depression and may predict
#              whether someone is inactive at wave 1.
#   age1     = baseline age.
#   male1    = biological sex.
#   illness1 = limiting longstanding illness.
#
# We do NOT control for notact2, because it is measured after notact1 and could be
# on a pathway from earlier activity to later depression.

mod[["Q2_adjusted_notact1_to_cesd2"]] <- lm(
  cesd2 ~ notact1 + cesd1 + age1 + male1 + illness1,
  data = elsa
)

cat("\n\n--- Q2: DAG-ADJUSTED LINEAR MODEL ---\n")
summary(mod[["Q2_adjusted_notact1_to_cesd2"]])

cat("\nKey coefficient for notact1:\n")
print(lm_row(mod[["Q2_adjusted_notact1_to_cesd2"]], "notact1"))

cat("\nR-squared:\n")
print(summary(mod[["Q2_adjusted_notact1_to_cesd2"]])$r.squared)

# Adjusted prediction: set covariates to their sample means and compare notact1=0 vs 1.
q2_pred <- data.frame(
  notact1 = c(0, 1),
  cesd1 = mean(elsa$cesd1),
  age1 = mean(elsa$age1),
  male1 = mean(elsa$male1),
  illness1 = mean(elsa$illness1)
)
q2_pred$predicted_cesd2 <- predict(mod[["Q2_adjusted_notact1_to_cesd2"]],
                                   newdata = q2_pred)

cat("\nAdjusted predicted wave-2 CES-D by wave-1 inactivity:\n")
print(q2_pred[, c("notact1", "predicted_cesd2")])


# ==============================================================================
# PART 4: Q3 - UNCONDITIONAL EFFECT OF cesd1 ON notact2
# ==============================================================================

# SCENARIO:
# Does baseline depression predict later lack of physical activity?
#
# Outcome:   notact2 (binary: 1 = no moderate weekly physical activity in wave 2)
# Predictor: cesd1   (baseline CES-D score)
#
# Because notact2 is binary, we use a binary logistic regression:
# glm(..., family = binomial).

mod[["Q3_unconditional_cesd1_to_notact2"]] <- glm(
  notact2 ~ cesd1,
  data = elsa,
  family = binomial
)

cat("\n\n--- Q3: UNCONDITIONAL LOGISTIC MODEL ---\n")
summary(mod[["Q3_unconditional_cesd1_to_notact2"]])

cat("\nKey coefficient for cesd1, with odds ratio:\n")
print(logit_row(mod[["Q3_unconditional_cesd1_to_notact2"]], "cesd1"))

cat("\nPseudo-R2 values:\n")
cat("McFadden:", round(mcfadden_r2(mod[["Q3_unconditional_cesd1_to_notact2"]]), 3), "\n")
cat("Tjur:", round(tjur_r2(mod[["Q3_unconditional_cesd1_to_notact2"]]), 3), "\n")

# Predicted probabilities for meaningful CES-D values.
q3_pred <- data.frame(cesd1 = c(0, 1, 2, 4, 8))
q3_pred$predicted_probability_notact2 <- predict(
  mod[["Q3_unconditional_cesd1_to_notact2"]],
  newdata = q3_pred,
  type = "response"
)

cat("\nPredicted probability of wave-2 inactivity by baseline CES-D:\n")
print(q3_pred)


# ==============================================================================
# PART 5: Q4 - DAG-ADJUSTED TOTAL EFFECT OF cesd1 ON notact2
# ==============================================================================

# DAG / BACK-DOOR LOGIC:
# For the total effect of cesd1 -> notact2, we adjust for pre-treatment common
# causes of depression and later inactivity.
#
# Controls:
#   notact1  = baseline physical inactivity. It strongly predicts later inactivity
#              and is related to baseline depression.
#   age1     = baseline age.
#   male1    = biological sex.
#   illness1 = limiting longstanding illness.
#
# We do NOT control for cesd2, because it is measured after cesd1.

mod[["Q4_adjusted_cesd1_to_notact2"]] <- glm(
  notact2 ~ cesd1 + notact1 + age1 + male1 + illness1,
  data = elsa,
  family = binomial
)

cat("\n\n--- Q4: DAG-ADJUSTED LOGISTIC MODEL ---\n")
summary(mod[["Q4_adjusted_cesd1_to_notact2"]])

cat("\nKey coefficient for cesd1, with odds ratio:\n")
print(logit_row(mod[["Q4_adjusted_cesd1_to_notact2"]], "cesd1"))

cat("\nAll odds ratios in the adjusted logistic model:\n")
print(exp(coef(mod[["Q4_adjusted_cesd1_to_notact2"]])))

cat("\nPseudo-R2 values:\n")
cat("McFadden:", round(mcfadden_r2(mod[["Q4_adjusted_cesd1_to_notact2"]]), 3), "\n")
cat("Tjur:", round(tjur_r2(mod[["Q4_adjusted_cesd1_to_notact2"]]), 3), "\n")

# Adjusted predicted probabilities:
# We compare CES-D values while holding age, sex, and illness at their means.
# We show probabilities separately for baseline active and inactive respondents.
q4_pred_active <- data.frame(
  cesd1 = c(0, 1, 2, 4, 8),
  notact1 = 0,
  age1 = mean(elsa$age1),
  male1 = mean(elsa$male1),
  illness1 = mean(elsa$illness1)
)
q4_pred_active$predicted_probability_notact2 <- predict(
  mod[["Q4_adjusted_cesd1_to_notact2"]],
  newdata = q4_pred_active,
  type = "response"
)

q4_pred_inactive <- q4_pred_active
q4_pred_inactive$notact1 <- 1
q4_pred_inactive$predicted_probability_notact2 <- predict(
  mod[["Q4_adjusted_cesd1_to_notact2"]],
  newdata = q4_pred_inactive,
  type = "response"
)

cat("\nAdjusted predicted probabilities if active at wave 1 (notact1=0):\n")
print(q4_pred_active[, c("cesd1", "notact1", "predicted_probability_notact2")])

cat("\nAdjusted predicted probabilities if inactive at wave 1 (notact1=1):\n")
print(q4_pred_inactive[, c("cesd1", "notact1", "predicted_probability_notact2")])


# ==============================================================================
# PART 6: COMPARISON TABLES FOR REPORT WRITING
# ==============================================================================

cat("\n\n--- REPORT-READY SUMMARY ---\n")

linear_summary <- data.frame(
  Model = c("Q1: cesd2 ~ notact1", "Q2: adjusted notact1 -> cesd2"),
  Key_Term = "notact1",
  b = c(
    lm_row(mod[["Q1_unconditional_notact1_to_cesd2"]], "notact1")["b"],
    lm_row(mod[["Q2_adjusted_notact1_to_cesd2"]], "notact1")["b"]
  ),
  SE = c(
    lm_row(mod[["Q1_unconditional_notact1_to_cesd2"]], "notact1")["SE"],
    lm_row(mod[["Q2_adjusted_notact1_to_cesd2"]], "notact1")["SE"]
  ),
  p = c(
    lm_row(mod[["Q1_unconditional_notact1_to_cesd2"]], "notact1")["p"],
    lm_row(mod[["Q2_adjusted_notact1_to_cesd2"]], "notact1")["p"]
  ),
  R2 = c(
    summary(mod[["Q1_unconditional_notact1_to_cesd2"]])$r.squared,
    summary(mod[["Q2_adjusted_notact1_to_cesd2"]])$r.squared
  )
)

logit_summary <- data.frame(
  Model = c("Q3: notact2 ~ cesd1", "Q4: adjusted cesd1 -> notact2"),
  Key_Term = "cesd1",
  b = c(
    logit_row(mod[["Q3_unconditional_cesd1_to_notact2"]], "cesd1")["b"],
    logit_row(mod[["Q4_adjusted_cesd1_to_notact2"]], "cesd1")["b"]
  ),
  SE = c(
    logit_row(mod[["Q3_unconditional_cesd1_to_notact2"]], "cesd1")["SE"],
    logit_row(mod[["Q4_adjusted_cesd1_to_notact2"]], "cesd1")["SE"]
  ),
  p = c(
    logit_row(mod[["Q3_unconditional_cesd1_to_notact2"]], "cesd1")["p"],
    logit_row(mod[["Q4_adjusted_cesd1_to_notact2"]], "cesd1")["p"]
  ),
  OR = c(
    logit_row(mod[["Q3_unconditional_cesd1_to_notact2"]], "cesd1")["OR"],
    logit_row(mod[["Q4_adjusted_cesd1_to_notact2"]], "cesd1")["OR"]
  ),
  McFadden_R2 = c(
    mcfadden_r2(mod[["Q3_unconditional_cesd1_to_notact2"]]),
    mcfadden_r2(mod[["Q4_adjusted_cesd1_to_notact2"]])
  ),
  Tjur_R2 = c(
    tjur_r2(mod[["Q3_unconditional_cesd1_to_notact2"]]),
    tjur_r2(mod[["Q4_adjusted_cesd1_to_notact2"]])
  )
)

print(round(linear_summary[, c("b", "SE", "p", "R2")], 4))
print(linear_summary[, c("Model", "Key_Term")])

print(round(logit_summary[, c("b", "SE", "p", "OR", "McFadden_R2", "Tjur_R2")], 4))
print(logit_summary[, c("Model", "Key_Term")])

cat("\nInterpretation note:\n")
cat("The adjusted coefficients are smaller than the unconditional coefficients, which is\n")
cat("evidence that baseline characteristics and prior status explain part of the raw\n")
cat("association. However, both adjusted key coefficients remain statistically significant.\n")

