-


 install.packages("estimatr")
 install.packages("modelsummary")

library(estimatr)      # For IV / 2SLS estimation: iv_robust()
library(modelsummary)  # For clean side-by-side regression tables


# ------------------------------------------------------------------------------
# PART 0: DATA LOADING AND BASIC CHECKS
# ------------------------------------------------------------------------------

data_path <- "/Users/zhonghao/Downloads/colonial_origins_clean.csv"
colonial <- read.csv(data_path)

# Make continent categorical so R creates dummy variables automatically.
colonial$continent <- factor(colonial$continent)

cat("\n--- PART 0: DATA CHECK ---\n")
cat("Sample size:", nrow(colonial), "\n")
cat("Number of variables:", ncol(colonial), "\n\n")

cat("Variable names:\n")
print(names(colonial))

cat("\nMissing values:\n")
print(colSums(is.na(colonial)))

cat("\nDescriptive statistics:\n")
print(summary(colonial))


# ------------------------------------------------------------------------------
# PART 1: HELPER FUNCTIONS
# ------------------------------------------------------------------------------

# Extract the key coefficient row from lm() output.
lm_key <- function(model, term) {
  out <- summary(model)$coefficients
  ci <- confint(model)
  c(
    b = out[term, "Estimate"],
    SE = out[term, "Std. Error"],
    t = out[term, "t value"],
    p = out[term, "Pr(>|t|)"],
    CI_low = ci[term, 1],
    CI_high = ci[term, 2],
    R2 = summary(model)$r.squared
  )
}

# Extract the key coefficient row from iv_robust() output.
iv_key <- function(model, term) {
  out <- summary(model)$coefficients
  row <- out[term, ]
  c(
    b = row["Estimate"],
    SE = row["Std. Error"],
    t = row["t value"],
    p = row["Pr(>|t|)"],
    CI_low = row["CI Lower"],
    CI_high = row["CI Upper"]
  )
}

# Store models in a list, following the tutorial style.
mod <- list()


# ==============================================================================
# PART 2: Q1 - UNCONDITIONAL OLS
# ==============================================================================

# SCENARIO:
# Do countries with better institutions have higher log GDP per capita?
#
# Outcome:   log_gdp
# Predictor: institutions
#
# This is a simple OLS model with no third variables.

mod[["Q1 OLS"]] <- lm(log_gdp ~ institutions, data = colonial)

cat("\n\n--- Q1: UNCONDITIONAL OLS ---\n")
summary(mod[["Q1 OLS"]])

cat("\nKey coefficient for institutions:\n")
print(lm_key(mod[["Q1 OLS"]], "institutions"))

q1_pred <- data.frame(institutions = c(4, 6, 8, 10))
q1_pred$predicted_log_gdp <- predict(mod[["Q1 OLS"]], newdata = q1_pred)

cat("\nPredicted log GDP by institutions:\n")
print(q1_pred)


# ==============================================================================
# PART 3: Q2 - FIRST STAGE
# ==============================================================================

# In an IV design, the instrument must be relevant:
# log_settler_mortality should predict institutions.

mod[["Q2 First Stage"]] <- lm(
  institutions ~ log_settler_mortality,
  data = colonial
)

cat("\n\n--- Q2: FIRST STAGE ---\n")
summary(mod[["Q2 First Stage"]])

cat("\nKey coefficient for log_settler_mortality:\n")
print(lm_key(mod[["Q2 First Stage"]], "log_settler_mortality"))

cat("\nFirst-stage F-statistic:\n")
print(summary(mod[["Q2 First Stage"]])$fstatistic)


# ==============================================================================
# PART 4: Q3 - REDUCED FORM
# ==============================================================================

# The reduced form estimates the relationship between the instrument and outcome:
# log_settler_mortality -> log_gdp.

mod[["Q3 Reduced Form"]] <- lm(
  log_gdp ~ log_settler_mortality,
  data = colonial
)

cat("\n\n--- Q3: REDUCED FORM ---\n")
summary(mod[["Q3 Reduced Form"]])

cat("\nKey coefficient for log_settler_mortality:\n")
print(lm_key(mod[["Q3 Reduced Form"]], "log_settler_mortality"))


# ==============================================================================
# PART 5: Q4 - IV / 2SLS WITHOUT CONTROLS
# ==============================================================================

# IV formula syntax in estimatr:
#   outcome ~ endogenous_variable | instrument
#
# Here we use log_settler_mortality as an instrument for institutions.
# se_type = "classical" keeps the standard errors comparable to the basic
# classroom 2SLS calculation. You can remove this option if your teacher asks
# for robust standard errors.

mod[["Q4 IV"]] <- iv_robust(
  log_gdp ~ institutions | log_settler_mortality,
  data = colonial,
  se_type = "classical"
)

cat("\n\n--- Q4: IV / 2SLS WITHOUT CONTROLS ---\n")
summary(mod[["Q4 IV"]])

cat("\nKey IV coefficient for institutions:\n")
print(iv_key(mod[["Q4 IV"]], "institutions"))


# ==============================================================================
# PART 6: Q5 - OLS AND IV WITH LATITUDE AND CONTINENT CONTROLS
# ==============================================================================

# Controls:
#   latitude  = geographic location / distance from equator
#   continent = broad regional category
#
# In IV, controls must appear on both sides of the vertical bar:
#   Y ~ endogenous + controls | instrument + controls

mod[["Q5 OLS Controls"]] <- lm(
  log_gdp ~ institutions + latitude + continent,
  data = colonial
)

mod[["Q5 First Stage Controls"]] <- lm(
  institutions ~ log_settler_mortality + latitude + continent,
  data = colonial
)

mod[["Q5 IV Controls"]] <- iv_robust(
  log_gdp ~ institutions + latitude + continent |
    log_settler_mortality + latitude + continent,
  data = colonial,
  se_type = "classical"
)

cat("\n\n--- Q5: OLS WITH CONTROLS ---\n")
summary(mod[["Q5 OLS Controls"]])

cat("\nKey OLS coefficient for institutions with controls:\n")
print(lm_key(mod[["Q5 OLS Controls"]], "institutions"))

cat("\n\n--- Q5: CONTROLLED FIRST STAGE ---\n")
summary(mod[["Q5 First Stage Controls"]])

cat("\nKey controlled first-stage coefficient for log_settler_mortality:\n")
print(lm_key(mod[["Q5 First Stage Controls"]], "log_settler_mortality"))

cat("\n\n--- Q5: IV / 2SLS WITH CONTROLS ---\n")
summary(mod[["Q5 IV Controls"]])

cat("\nKey IV coefficient for institutions with controls:\n")
print(iv_key(mod[["Q5 IV Controls"]], "institutions"))


# ==============================================================================
# PART 7: COMPARISON TABLES
# ==============================================================================

cat("\n\n--- MODEL COMPARISON TABLES ---\n")

# Main OLS / IV comparison.
msummary(
  mod[c("Q1 OLS", "Q4 IV", "Q5 OLS Controls", "Q5 IV Controls")],
  coef_omit = "continent",
  stars = TRUE,
  gof_omit = "AIC|BIC|Log.Lik.|RMSE|F|Std.Errors",
  title = "OLS and IV Estimates of Institutions on Log GDP"
)

# First-stage and reduced-form models.
msummary(
  mod[c("Q2 First Stage", "Q3 Reduced Form", "Q5 First Stage Controls")],
  coef_omit = "continent",
  stars = TRUE,
  gof_omit = "AIC|BIC|Log.Lik.|RMSE",
  title = "First Stage and Reduced Form Models"
)


# ==============================================================================
# PART 8: REPORT-READY SUMMARY
# ==============================================================================

cat("\n\n--- REPORT-READY SUMMARY ---\n")

summary_table <- data.frame(
  Model = c(
    "Q1 OLS",
    "Q2 first stage",
    "Q3 reduced form",
    "Q4 IV",
    "Q5 OLS controls",
    "Q5 IV controls"
  ),
  Key_Term = c(
    "institutions",
    "log_settler_mortality",
    "log_settler_mortality",
    "institutions",
    "institutions",
    "institutions"
  ),
  b = c(
    lm_key(mod[["Q1 OLS"]], "institutions")["b"],
    lm_key(mod[["Q2 First Stage"]], "log_settler_mortality")["b"],
    lm_key(mod[["Q3 Reduced Form"]], "log_settler_mortality")["b"],
    iv_key(mod[["Q4 IV"]], "institutions")["b"],
    lm_key(mod[["Q5 OLS Controls"]], "institutions")["b"],
    iv_key(mod[["Q5 IV Controls"]], "institutions")["b"]
  ),
  SE = c(
    lm_key(mod[["Q1 OLS"]], "institutions")["SE"],
    lm_key(mod[["Q2 First Stage"]], "log_settler_mortality")["SE"],
    lm_key(mod[["Q3 Reduced Form"]], "log_settler_mortality")["SE"],
    iv_key(mod[["Q4 IV"]], "institutions")["SE"],
    lm_key(mod[["Q5 OLS Controls"]], "institutions")["SE"],
    iv_key(mod[["Q5 IV Controls"]], "institutions")["SE"]
  ),
  p = c(
    lm_key(mod[["Q1 OLS"]], "institutions")["p"],
    lm_key(mod[["Q2 First Stage"]], "log_settler_mortality")["p"],
    lm_key(mod[["Q3 Reduced Form"]], "log_settler_mortality")["p"],
    iv_key(mod[["Q4 IV"]], "institutions")["p"],
    lm_key(mod[["Q5 OLS Controls"]], "institutions")["p"],
    iv_key(mod[["Q5 IV Controls"]], "institutions")["p"]
  )
)

print(summary_table)
cat("\nRounded numeric summary:\n")
print(round(summary_table[, c("b", "SE", "p")], 4))


